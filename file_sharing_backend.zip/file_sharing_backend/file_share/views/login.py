from rest_framework.views import APIView
from file_share.serializers.serializers import LoginValidationSerializer
from file_share.models import UserAccount
from rest_framework.response import Response
from rest_framework import status

class LoginAPIView(APIView):
    def post(self, request):
        request_data = request.data
        serializer = LoginValidationSerializer(data=request_data)
        serializer.is_valid(raise_exception=True)

        is_user_exist = UserAccount.objects.filter(email=request_data["email"], password=request_data["password"])
        if is_user_exist:
            return Response("Successfully logged in", status=status.HTTP_200_OK)
        else:
            return Response("Don't have user account please register", status=status.HTTP_404_NOT_FOUND)


