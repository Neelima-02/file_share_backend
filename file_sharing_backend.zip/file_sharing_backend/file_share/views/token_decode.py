import requests

from jose.exceptions import JWTError
from django.http import HttpResponse
from jose import jwt
from rsa import PublicKey


def decode_jwt_token(access_token):
    try:
        decoded_token = jwt.decode(access_token, algorithms=['RS256'], options={'verify_signature': False})
        print("decoded_token", decoded_token)
        return decoded_token
    except JWTError as e:
        raise ValueError(f"Invalid Token: {str(e)}")

result = decode_jwt_token("")
print("------")
print("result", result)